package poly;

public abstract class BangunDatar {
    public abstract void luas();
    public abstract void keliling();
}
